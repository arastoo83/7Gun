<?php

namespace humhub\modules\search\events;

use yii\base\Event;

/**
 * @deprecated since 1.16
 */
class SearchAddEvent extends Event
{
    public function __construct($attributes)
    {
    }
}
