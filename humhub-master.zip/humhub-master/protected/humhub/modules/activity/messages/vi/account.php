<?php
return array (
  'E-Mail Summaries' => 'Tổng hợp E-mail',
);
