<?php
return array (
  'E-Mail Summaries' => 'Correus de resumen',
);
