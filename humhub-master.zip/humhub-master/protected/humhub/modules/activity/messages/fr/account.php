<?php
return array (
  'E-Mail Summaries' => 'Résumés par e-mail',
);
