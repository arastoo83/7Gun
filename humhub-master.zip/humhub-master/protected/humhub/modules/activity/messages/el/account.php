<?php
return array (
  'E-Mail Summaries' => 'Περιλήψεις ηλ. ταχυδρομείου',
);
