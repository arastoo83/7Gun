<?php
return array (
  'E-Mail Summaries' => 'Resúmenes de Correo',
);
