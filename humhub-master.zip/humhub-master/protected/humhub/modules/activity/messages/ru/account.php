<?php /* Translated by Paul (https://paul.bid) www.paul.bid@gmail.com */
return [
    'E-Mail Summaries' => 'Email уведомления',
];
