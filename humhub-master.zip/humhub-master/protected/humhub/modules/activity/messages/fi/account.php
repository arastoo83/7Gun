<?php
return array (
  'E-Mail Summaries' => 'Sähköposti ilmoitukset',
);
