<?php
return array (
  'E-Mail Summaries' => 'Podsumowania e-mail',
);
