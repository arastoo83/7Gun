<?php
return array (
  'E-Mail Summaries' => '이메일 요약',
);
