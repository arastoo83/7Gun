<?php
return array (
  'E-Mail Summaries' => 'E-post sammendrag',
);
