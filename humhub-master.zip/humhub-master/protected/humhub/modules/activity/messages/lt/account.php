<?php
return array (
  'E-Mail Summaries' => 'Pranešimai el.paštu',
);
