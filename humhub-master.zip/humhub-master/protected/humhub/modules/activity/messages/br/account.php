<?php
return array (
  'E-Mail Summaries' => 'Diverradennoù dre bostel',
);
