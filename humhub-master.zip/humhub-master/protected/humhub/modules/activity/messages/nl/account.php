<?php
return array (
  'E-Mail Summaries' => 'E-mailoverzichten',
);
