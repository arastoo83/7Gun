<?php

return [
    '<strong>Login</strong> required' => 'Yêu cầu <strong>Đăng nhập</strong>',
    'An internal server error occurred.' => 'Xảy ra lỗi máy chủ.',
    'Guest mode not active, please login first.' => 'Chỉ thành viên mới được truy cập, vui lòng đăng nhập.',
    'Login required for this section.' => 'Yêu cầu đăng nhập',
    'You are not allowed to perform this action.' => 'Bạn không được phép thực hiện hành động này.',
    'You are not permitted to access this section.' => 'Bạn không có quyền truy cập khu vực này',
    'You need admin permissions to access this section.' => 'Bạn cần quyền quản trị để truy cập khu vực này',
    'Your user account has not been approved yet, please try again later or contact a network administrator.' => 'Tài khoản của bạn chưa được duyệt, vui lòng thử lại sau hoặc liên hệ với quản trị hệ thống để được hỗ trợ.',
    'Your user account is inactive, please login with an active account or contact a network administrator.' => 'Tài khoản của bạn bị ngưng kích hoạt, vui lòng đăng nhập bằng tài khoản đã được kích hoạt hoặc liên hệ quản trị hệ thống để được hỗ trợ.',
    'Maintenance mode activated: You have been automatically logged out and will no longer have access the platform until the maintenance has been completed.' => '',
    'Maintenance mode is active. Only Administrators can access the platform.' => '',
    'The module {moduleId} is present in the HumHub configuration file even though this module is disabled. Please remove it from the configuration.' => '',
    'The specified URL cannot be called directly.' => '',
    'You must change password.' => '',
];
