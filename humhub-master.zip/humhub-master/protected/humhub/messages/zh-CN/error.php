<?php

return [
    '<strong>Login</strong> required' => '<strong>必须</strong> 登录',
    'An internal server error occurred.' => '发生了一个内部错误。',
    'You are not allowed to perform this action.' => '你没有权限执行此操作。',
    'Guest mode not active, please login first.' => '',
    'Login required for this section.' => '',
    'Maintenance mode activated: You have been automatically logged out and will no longer have access the platform until the maintenance has been completed.' => '',
    'Maintenance mode is active. Only Administrators can access the platform.' => '',
    'The module {moduleId} is present in the HumHub configuration file even though this module is disabled. Please remove it from the configuration.' => '',
    'The specified URL cannot be called directly.' => '',
    'You are not permitted to access this section.' => '',
    'You must change password.' => '',
    'You need admin permissions to access this section.' => '',
    'Your user account has not been approved yet, please try again later or contact a network administrator.' => '',
    'Your user account is inactive, please login with an active account or contact a network administrator.' => '',
];
