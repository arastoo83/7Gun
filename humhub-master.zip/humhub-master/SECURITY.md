# Security Policy

## Reporting a Vulnerability

You can report vulnerabilities privately to [security@humhub.com](mailto:security@humhub.com). 
The HumHub team will triage the issue, and work with you on a coordinated disclosure timeline.
